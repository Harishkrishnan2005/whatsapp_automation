import mongoose from 'mongoose';
import COLLECTIONS from '../config/mongoCollections.js';

const supportTicketSchema = new mongoose.Schema(
  {
    businessId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Business',
      required: true,
      index: true,
    },
    tenantId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Business',
      required: true,
      index: true,
    },
    customerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Customer',
      required: true,
    },
    subject: {
      type: String,
      required: true,
      trim: true,
    },
    message: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      enum: ['OPEN', 'IN_PROGRESS', 'RESOLVED'],
      default: 'OPEN',
    },
    assignedTo: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    replies: [
      {
        sender: {
          type: String,
          enum: ['admin', 'super_admin', 'staff', 'bot', 'customer'],
          required: true,
        },
        message: {
          type: String,
          required: true,
        },
        timestamp: {
          type: Date,
          default: Date.now,
        },
      },
    ],
  },
  {
    timestamps: true,
    collection: COLLECTIONS.SUPPORT_TICKETS || 'support_tickets',
  }
);

supportTicketSchema.index({ tenantId: 1, status: 1 });
supportTicketSchema.index({ tenantId: 1, customerId: 1 });
supportTicketSchema.index({ tenantId: 1, assignedTo: 1, status: 1 });

export default mongoose.model('SupportTicket', supportTicketSchema);
